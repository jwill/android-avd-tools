if (typeof kotlin === 'undefined') {
  throw new Error("Error loading module 'ShapeShifterBabylon'. Its dependency 'kotlin' was not found. Please, check whether 'kotlin' is loaded prior to 'ShapeShifterBabylon'.");
}
var ShapeShifterBabylon = function (_, Kotlin) {
  'use strict';
  var throwUPAE = Kotlin.throwUPAE;
  var Mesh = BABYLON.Mesh;
  var throwCCE = Kotlin.throwCCE;
  var println = Kotlin.kotlin.io.println_s8jyv4$;
  var Unit = Kotlin.kotlin.Unit;
  var Scene = BABYLON.Scene;
  var math = Kotlin.kotlin.math;
  var Vector3$Companion = BABYLON.Vector3;
  var ArcRotateCamera = BABYLON.ArcRotateCamera;
  var HemisphericLight = BABYLON.HemisphericLight;
  var PointLight = BABYLON.PointLight;
  var Engine = BABYLON.Engine;
  var SceneLoader$Companion = BABYLON.SceneLoader;
  var Kind_CLASS = Kotlin.Kind.CLASS;
  var defineInlineFunction = Kotlin.defineInlineFunction;
  var Kind_INTERFACE = Kotlin.Kind.INTERFACE;
  function GLTFSample(filename) {
    var tmp$;
    this.canvas = Kotlin.isType(tmp$ = document.getElementById('renderCanvas'), HTMLCanvasElement) ? tmp$ : throwCCE();
    this.engine = null;
    this.scene = null;
    this.mesh_r8kktc$_0 = this.mesh_r8kktc$_0;
    this.engine = new Engine(this.canvas, true);
    this.engine.enableOfflineSupport = false;
    this.scene = this.createScene();
    println('hello');
    println(this.engine);
    println(this.scene);
    this.engine.runRenderLoop(GLTFSample_init$lambda(this));
    window.addEventListener('resize', GLTFSample_init$lambda_0(this));
    SceneLoader$Companion.Append('models/', filename, this.scene, GLTFSample_init$lambda_1(this));
  }
  Object.defineProperty(GLTFSample.prototype, 'mesh', {
    get: function () {
      if (this.mesh_r8kktc$_0 == null)
        return throwUPAE('mesh');
      return this.mesh_r8kktc$_0;
    },
    set: function (mesh) {
      this.mesh_r8kktc$_0 = mesh;
    }
  });
  GLTFSample.prototype.loadGLTFScene_jkzhlf$ = function (scene) {
    var tmp$;
    this.mesh = Kotlin.isType(tmp$ = scene.meshes[0], Mesh) ? tmp$ : throwCCE();
    println(scene.animations);
    var $receiver = scene.meshes;
    var tmp$_0;
    for (tmp$_0 = 0; tmp$_0 !== $receiver.length; ++tmp$_0) {
      var element = $receiver[tmp$_0];
      var tmp$_1;
      var mesh = Kotlin.isType(tmp$_1 = element, Mesh) ? tmp$_1 : throwCCE();
      if (mesh.geometry != null) {
        println(mesh.name);
        println(mesh.geometry);
      }
    }
  };
  GLTFSample.prototype.saveFile = function () {
    var text = [1, 2, 3];
    var type = 'text/plain';
    var o = {};
    o['type'] = type;
    var blob = new Blob(text, o);
    saveAs(blob, 'file-data.txt');
  };
  GLTFSample.prototype.createScene = function () {
    var scene = new Scene(this.engine);
    var camera = new ArcRotateCamera('Camera', math.PI / 2, math.PI / 2, 2, Vector3$Companion.Zero(), scene);
    camera.attachControl(this.canvas, true);
    var light1 = new HemisphericLight('light1', new Vector3$Companion(1, 1, 0), scene);
    var light2 = new PointLight('light2', new Vector3$Companion(0, 1, -1), scene);
    return scene;
  };
  function GLTFSample_init$lambda(this$GLTFSample) {
    return function () {
      this$GLTFSample.scene.render();
      return Unit;
    };
  }
  function GLTFSample_init$lambda_0(this$GLTFSample) {
    return function (it) {
      this$GLTFSample.engine.resize();
      return Unit;
    };
  }
  function GLTFSample_init$lambda_1(this$GLTFSample) {
    return function (it) {
      this$GLTFSample.loadGLTFScene_jkzhlf$(it);
      return Unit;
    };
  }
  GLTFSample.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'GLTFSample',
    interfaces: []
  };
  var get_getVRDisplays = defineInlineFunction('ShapeShifterBabylon.get_getVRDisplays_yi0el1$', function ($receiver) {
    return $receiver.getVRDisplays;
  });
  var set_getVRDisplays = defineInlineFunction('ShapeShifterBabylon.set_getVRDisplays_9lst89$', function ($receiver, value) {
    $receiver.getVRDisplays = value;
  });
  var getGamepads = defineInlineFunction('ShapeShifterBabylon.getGamepads_yi0el1$', function ($receiver) {
    return $receiver.getGamepads();
  });
  var get_activeVRDisplays = defineInlineFunction('ShapeShifterBabylon.get_activeVRDisplays_yi0el1$', function ($receiver) {
    return $receiver.activeVRDisplays;
  });
  var set_activeVRDisplays = defineInlineFunction('ShapeShifterBabylon.set_activeVRDisplays_celwse$', function ($receiver, value) {
    $receiver.activeVRDisplays = value;
  });
  function Promise() {
  }
  Promise.prototype.then_2rzt3y$ = function (onFulfilled, onTejected, callback$default) {
    if (onFulfilled === void 0)
      onFulfilled = null;
    if (onTejected === void 0)
      onTejected = null;
    return callback$default ? callback$default(onFulfilled, onTejected) : this.then_2rzt3y$$default(onFulfilled, onTejected);
  };
  Promise.prototype.catch_57jjaz$ = function (onTejected, callback$default) {
    if (onTejected === void 0)
      onTejected = null;
    return callback$default ? callback$default(onTejected) : this.catch_57jjaz$$default(onTejected);
  };
  Promise.prototype.done_2rzt3y$ = function (onFulfilled, onTejected, callback$default) {
    if (onFulfilled === void 0)
      onFulfilled = null;
    if (onTejected === void 0)
      onTejected = null;
    return callback$default ? callback$default(onFulfilled, onTejected) : this.done_2rzt3y$$default(onFulfilled, onTejected);
  };
  Promise.$metadata$ = {
    kind: Kind_INTERFACE,
    simpleName: 'Promise',
    interfaces: []
  };
  _.GLTFSample = GLTFSample;
  _.get_getVRDisplays_yi0el1$ = get_getVRDisplays;
  _.set_getVRDisplays_9lst89$ = set_getVRDisplays;
  _.getGamepads_yi0el1$ = getGamepads;
  _.get_activeVRDisplays_yi0el1$ = get_activeVRDisplays;
  _.set_activeVRDisplays_celwse$ = set_activeVRDisplays;
  _.Promise = Promise;
  Kotlin.defineModule('ShapeShifterBabylon', _);
  return _;
}(typeof ShapeShifterBabylon === 'undefined' ? {} : ShapeShifterBabylon, kotlin);
