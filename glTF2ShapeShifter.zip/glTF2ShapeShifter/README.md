Used this for typesafety in BabylonJS
https://github.com/tlaukkan/babylonjs-kotlin
