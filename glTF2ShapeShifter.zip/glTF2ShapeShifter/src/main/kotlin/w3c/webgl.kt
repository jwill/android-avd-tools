package org.khronos.webgl

external open class WEBGL_compressed_texture_s3tc : Any

external open class EXT_texture_filter_anisotropic : Any

external open class WebGLVertexArrayObject : Any