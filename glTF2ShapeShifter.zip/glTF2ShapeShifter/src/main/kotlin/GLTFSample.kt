import BABYLON.*
import org.w3c.dom.Element
import org.w3c.dom.HTMLAnchorElement
import org.w3c.dom.HTMLCanvasElement
import org.w3c.dom.get
import org.w3c.files.Blob
import org.w3c.files.BlobPropertyBag
import kotlin.browser.document
import kotlin.browser.window
import kotlin.js.Math

external fun require(module: String): dynamic
// provided by FileSaver.js
external fun saveAs(blob:Blob, filename: String)

class GLTFSample(filename:String) {
    var canvas: HTMLCanvasElement = document.getElementById("renderCanvas") as HTMLCanvasElement
    //var BABYLON = js("BABYLON")
    var engine: Engine
    var scene: Scene
    lateinit var mesh:Mesh


    init {
        engine = BABYLON.Engine(canvas, true)
        engine.enableOfflineSupport = false

        scene = createScene()

        println("hello")
        println(engine)
        println(scene)

        engine.runRenderLoop {
            scene.render()
        }

        window.addEventListener("resize", {
            engine.resize()
        })

        BABYLON.SceneLoader.Append("models/", filename, scene,{
            loadGLTFScene(it)

        })
    }



    fun loadGLTFScene(scene:Scene) {
        mesh = scene.meshes[0] as Mesh
        println(scene.animations)

        scene.meshes.forEach {
            val mesh = it as Mesh
            if (mesh.geometry != null) {
                println(mesh.name)
                println(mesh.geometry)
                //val material = it?.material
                //println(material)
            }
        }


    }

    fun saveFile() {
        val text = arrayOf(1, 2, 3)
        val blob = Blob(text, BlobPropertyBag("text/plain"))
        saveAs(blob, "file-data.txt")
    }

    fun createScene() : Scene {
        // Create the scene space
        val scene = BABYLON.Scene(engine)

        // Add a camera
        val camera = BABYLON.ArcRotateCamera("Camera", kotlin.math.PI / 2,
                kotlin.math.PI / 2, 2, BABYLON.Vector3.Zero(), scene)

        camera.attachControl(canvas, true)

        val light1 = HemisphericLight("light1", Vector3(1,1,0), scene)
        val light2 = PointLight("light2", Vector3(0,1,-1), scene)


       // val sphere = js("new BABYLON.MeshBuilder.CreateSphere('sphere',{diameter:2}, scene);")

        return scene
    }

//    fun resize(event: Event?) {
//        engine.resize()
//    }

}